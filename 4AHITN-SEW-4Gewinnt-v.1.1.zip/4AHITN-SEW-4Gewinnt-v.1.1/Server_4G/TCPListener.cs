﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;

namespace Server_4G
{
    class TCPListener
    {
        IPAddress _Address;
        IPEndPoint _EndPoint;
        Socket _Socket;

        public void Listen()
        {
            Console.WriteLine("Es wurde eine Anfrage getätigt");
            while (true)
            {
                Socket communicationSocket = null;
                try
                {
                    communicationSocket = _Socket.Accept(); // Prüft ob Verbindung aufgebaut wurde
                }
                catch (SocketException)
                {

                }

                if (communicationSocket.Connected) // wenn ja dann finde den hashcode heraus
                {

                    byte[] buffer1 = new byte[1024];
                    communicationSocket.Receive(buffer1);
                    string command = Encoding.ASCII.GetString(buffer1);
                    string hashcode = Convert.ToString(command.GetHashCode());
                    byte[] buffer2 = new byte[1024];
                    buffer2 = Encoding.ASCII.GetBytes(hashcode);
                    communicationSocket.Send(buffer2);

                }
            }

        }


        public TCPListener()
        {
            _Address = IPAddress.Loopback;
            _EndPoint = new IPEndPoint(_Address, 8877);
            _Socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            _Socket.Bind(_EndPoint);
            _Socket.Listen(10);
        }
    }
}
