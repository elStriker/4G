﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;

namespace Server_4G
{
    class Program
    {
        static void Main(string[] args)
        {
            IPAddress _Address = IPAddress.Loopback; //setzt IpAddress als loopback
            IPEndPoint _EndPoint = new IPEndPoint(_Address, 7766); //erstellt endpoint (aus ip und port)
            Socket _ClientSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp); //erstellt socket (hört nur auf strings, Stream)

            Console.WriteLine("Ich bin der Client amk");
            _ClientSocket.Connect(IPAddress.Loopback, 8877);

            while (true)
            {

                // verbindet socket mit endpoint
                //---String einlesen -> Umwandeln in Byte[] -> byte[] wegschicken

                string command = Console.ReadLine();
                byte[] buffer1 = new byte[1024];
                buffer1 = Encoding.ASCII.GetBytes(command); //Umwandeln bin string zu byte[]
                _ClientSocket.Send(buffer1); // Socket kann nu bytes schicken

                //---Antwort bekommen -> string umwandeln -> konsole ausgeben

                byte[] buffer2 = new byte[1024];
                _ClientSocket.Receive(buffer2);
                string ausgabe = Encoding.ASCII.GetString(buffer2);
                Console.WriteLine(ausgabe);

            }
        }
    }
}
