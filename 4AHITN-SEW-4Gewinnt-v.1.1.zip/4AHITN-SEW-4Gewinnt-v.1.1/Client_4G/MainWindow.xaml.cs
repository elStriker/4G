﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Net;
using System.Net.Sockets;

namespace Client_4G
{
    /// <summary>
    /// Interaktionslogik für MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

                IPAddress _Address = IPAddress.Loopback; //setzt IpAddress als loopback
                IPEndPoint _EndPoint = new IPEndPoint(_Address, 7766); //erstellt endpoint (aus ip und port)
                Socket _ClientSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp); //erstellt socket (hört nur auf strings, Stream)

                Console.WriteLine("Ich bin der Client amk");
                _ClientSocket.Connect(IPAddress.Loopback, 8877);

                while (true)
                {

                    // verbindet socket mit endpoint
                    //---String einlesen -> Umwandeln in Byte[] -> byte[] wegschicken

                    string command = Console.ReadLine();
                    byte[] buffer1 = new byte[1024];
                    buffer1 = Encoding.ASCII.GetBytes(command); //Umwandeln bin string zu byte[]
                    _ClientSocket.Send(buffer1); // Socket kann nu bytes schicken

                    //---Antwort bekommen -> string umwandeln -> konsole ausgeben

                    byte[] buffer2 = new byte[1024];
                    _ClientSocket.Receive(buffer2);
                    string ausgabe = Encoding.ASCII.GetString(buffer2);
                lbx_ausgabe.Items.Add(ausgabe);

                }
        }

        private void btn_connect_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
